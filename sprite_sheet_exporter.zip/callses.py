class SpriteSheetExporterType:
    filepath: str
    clear_output_folder: bool
    run_render: bool
