
class SpriteSheetExporterType:
    filepath: str
    clear_output_folder: bool
    run_render: bool
    export_angels: str
    safe_type: str
    camera_pivot_name: str
    padding_v: int
    padding_h: int
